#include "UDPSocket.h"
#include <sys/types.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <sys/socket.h>
#include <unistd.h>
#include <string.h>

using namespace npl;

UDPSocket::UDPSocket(int port){
	/**
	 * int socket(int domain, int type, int protocol);
	 * creates a UDP socket
	 * AF_INET - IPv4 Internet protocols
	 * SOCK_DGRAM - UDP
	 * 0 - default protocol type fo UDP
	 */
	socket_fd = socket (AF_INET, SOCK_DGRAM, 0);

	// clear the s_in struct
	int sockfd;
	struct sockaddr_in my_addr; // my address information
	struct sockaddr_in their_addr; // connector’s address information
	int addr_len, numbytes;
	char buf[100];
	if ((sockfd = socket(AF_INET, SOCK_DGRAM, 0)) == -1) {
		perror("socket");
	}
	//sets the sin address
	short sport = port;
	my_addr.sin_family = AF_INET; // host byte order
	my_addr.sin_port = htons(sport); // short, network byte order
	my_addr.sin_addr.s_addr = INADDR_ANY; // automatically fill with my IP
	memset(&(my_addr.sin_zero), '\0', 8); // zero the rest of the struct
	
}

int UDPSocket::recv(char* buffer, int length){
	int sockfd;
        struct sockaddr_in my_addr; // my address information
        struct sockaddr_in their_addr; // connector’s address information
        int addr_len, numbytes;
        char buf[100];
	printf("got packet from %s\n",inet_ntoa(their_addr.sin_addr));
	printf("packet is %d bytes long\n",numbytes);
	buf[numbytes] = '\0';
	printf("packet contains \"%s\"\n",buf);
	close(sockfd);
	return 0;
}


int UDPSocket::sendTo(const string& msg,const string& ip, int port){
	return -1;
}

int UDPSocket::reply(const string& msg){
	return -1;
}

void UDPSocket::close(int socket_fd){
	cout<<"closing socket"<<endl;
	shutdown(socket_fd,SHUT_RDWR);
	::close(socket_fd);
}

string UDPSocket::fromAddr(){
	return inet_ntoa(from.sin_addr);
}



