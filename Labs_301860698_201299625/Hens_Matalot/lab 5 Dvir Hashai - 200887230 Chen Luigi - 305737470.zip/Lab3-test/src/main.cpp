/*
 * main.cpp
 *
 *  Created on: Mar 13, 2016
 *      Author: user
 */


#include <iostream>
#include <string.h>
//#include "UdpSocketTest.h"
#include "TCPSocketTest.h"

using namespace std;
using namespace npl;

int main() {
	bool passFlag = true;
//	UdpSocketTest udpTest;
//	if(!udpTest.test()){
//		passFlag = false;
//		cerr<<endl<<"UDP test failed"<<endl;
//	}

	TCPSocketTest tcpTest;
	if(!tcpTest.test()){
		passFlag = false;
		cerr<<endl<<"TCP test failed"<<endl;
	}

	if(passFlag){
		cerr<<endl<<"*** TEST PASS ***"<<endl;
	}else{
		cerr<<endl<<"*** TEST FAIL ***"<<endl;
	}
}



