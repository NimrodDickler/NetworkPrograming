/*
 * TcpSocketTest.cpp
 *
 *  Created on: Mar 13, 2016
 *      Author: user
 */

#include "TCPSocketTest.h"


using namespace npl;

bool TCPSocketTest::test(){
	start();
	sleep(1);

	TCPSocket* client = new TCPSocket("127.0.0.1",6569);
	string msg = "12345678901234567890";
	client->send(msg);
	char buff[1024];
	int rc = client->recv(buff,sizeof(buff));
	buff[rc] = '\0';
	client->close();
	delete client;

	if(rc == (int)msg.size()){
		if(strcmp(msg.c_str(),buff) == 0){
			return true;
		}
	}
	cerr<<"TCP test failed"<<endl;
	waitForThread();
	return false;
}

void TCPSocketTest::run(){
	cout<<"open server"<<endl;
	TCPSocket* server = new TCPSocket(6569);
	TCPSocket* peer = server->listenAndAccept();
	char buff[1024];
	cout<<"got client connection"<<endl;
	int rc = peer->recv(buff,sizeof(buff));
	buff[rc] = '\0';
	cout<<"server :"<<buff<<endl;
	peer->send(buff);
	cout<<"server sent msg"<<endl;
	peer->close();
	server->close();
	delete peer;
	delete server;
}
