/*
 * TcpSocketTest.cpp
 *
 *  Created on: Mar 13, 2016
 *      Author: user
 */

#include "TcpSocketTest.h"
using namespace npl;
/*
 * The method is a implement of run function from class MThread
 * and run the server in a thread.
 * The method is testing the server side .
 */
void TcpSocketTest::run(){
	TCPSocket* Server = new TCPSocket(9999);
	TCPSocket* peer = Server->listenAndAccept();
	char buffer[100];
	int rc = peer->recv(buffer,sizeof(buffer));
	buffer[rc] = '\0';
	peer->send(buffer);
	peer->close();
	Server->close();
	delete peer;
	delete Server;
}

/*
 * The method is testing the client side .
 */
bool TcpSocketTest::test(){
	this->start();
	sleep(1);
	TCPSocket* client = new TCPSocket("127.0.0.1",9999);
	string msg = "Dvir & Chen lab 4";

	client->send(msg);
	char buffer[100];
	int rc = client->recv(buffer,sizeof(buffer));
	buffer[rc] = '\0';
	client->close();
	delete client;
	if(rc == msg.size()){
		if(strcmp(msg.c_str(),buffer)==0){
			return true;
		}
	}
	cout<<"TCP test faild"<<endl;
	waitForThread();
	return false;


}





