/*
 * main.cpp

 *
 *  Created on: Mar 13, 2016
 *      Author: user
 */
#include <iostream>
#include <string.h>
#include "UDPSocket.h"
#include "UdpSocketTest.h"
#include "TcpSocketTest.h"
using namespace std;
using namespace npl;

int main(){
	bool passFlage = true;
	UdpSocketTest udpTest;
	udpTest.test();

	if(!udpTest.test()){
		cerr<<endl<<"UDP test falid"<< endl;
		passFlage = false;
	}
	TcpSocketTest TCPTest;
	if(!TCPTest.test()){
		cerr<<endl<<"TCP test falid"<< endl;
		passFlage = false;
	}
	if(passFlage){
		cout<<endl<<endl<<"************* TEST PASS***********"<< endl;
	}
	else{
		cout<<endl<<endl<<"************* TEST FAILD***********"<< endl;
	}

}


