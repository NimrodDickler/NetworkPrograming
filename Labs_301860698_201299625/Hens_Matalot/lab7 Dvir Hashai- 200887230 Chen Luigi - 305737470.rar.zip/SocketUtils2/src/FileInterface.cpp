/*
 * FileInterface.cpp
 *
 *  Created on: Apr 20, 2016
 *      Author: user
 */

#include "FileInterface.h"


using namespace npl;




FileInterface:: ~FileInterface(){

}


