//============================================================================
// Name        : UDPMessenger
// Author      : Eliav Menachi
// Version     :
// Copyright   : Your copyright notice
// Description : UDP Messenger application
//============================================================================

#include "UDPMessenger.h"

using namespace std;
using namespace npl;


/*
 * run() function (pure virtual function from MThread class)
 * this function running in thread and waiting for incoming message
 */
void UDPMessenger::run() {
	// receiver thread...
	while (runing) {
		char buffer[1024];
		int n = udpSocket->recv(buffer, sizeof(buffer));
		if(n < 0){
			break;
		}
		buffer[n] = '\0';
		cout<<endl<<"the msg--->"<< buffer<<endl;
		cout<< "reciv from : " << udpSocket->fromAddr() << endl;
	}

	cout << "closing receiver thread" << endl;

}

/*
 * constructor for our UDPmessenger application
 * Initialize the connection port and start the run function
 */
UDPMessenger::UDPMessenger() {
	// init the messenger
	udpSocket = new UDPSocket(MSNGR_PORT);
	runing = true;
	this->start();
}

//send to function to send message
void UDPMessenger::sendTo(const string& msg, const string& ip) {
	udpSocket->sendTo(msg, ip, MSNGR_PORT);
}

//reply function to reply message
void UDPMessenger::reply(const string& msg) {
	udpSocket->reply(msg);
}

//close function to close our connection safely
void UDPMessenger::close() {
	runing = false;
	udpSocket->close();
	waitForThread();
	delete udpSocket;
	udpSocket = NULL;
}

